package com.jspiders.multithreadingwaitandnotify;

public class app {

}
