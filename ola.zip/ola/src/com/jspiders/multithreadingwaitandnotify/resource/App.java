package com.jspiders.multithreadingwaitandnotify.resource;

public class App {

}
